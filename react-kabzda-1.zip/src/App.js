import React from 'react';
import './App.css';
import HeaderContainer from './components/Header/HeaderContainer';
import Nav from './components/Navbar/Navbar';
import ProfileContainer from './components/Profile/ProfileContainer';
import LoginPage from './components/Login/Login';
import UsersContainer from './components/Users/UsersContainer';
import DialogsContainer from './components/Dialogs/DialogsContainer';
import {Route} from 'react-router-dom';

const App = (props) => {

  return (
      <div className='app-wrapper'>
        <HeaderContainer />
        <Nav />
        <div className="app-wrapper-content">
          <Route path="/profile/:userId?" render={ () => <ProfileContainer store={props.store}/> }/>
          <Route path="/dialogs" render={ () => <DialogsContainer store={props.store}/> }/>  
          <Route path="/users" render={ () => <UsersContainer store={props.store}/> }/> 
          <Route path="/login" render={ () => <LoginPage store={props.store}/> }/> 



          {/*     
          <Route exact path="/news" render={ () => <Profile profilePage={props.state.profilePage} addPost={props.addPost} updateNewPostText={props.updateNewPostText}/> }/>
          <Route path="/music" render={ () => <Profile profilePage={props.state.profilePage} addPost={props.addPost} updateNewPostText={props.updateNewPostText}/> }/>
          <Route path="/settings" render={ () => <Profile profilePage={props.state.profilePage} addPost={props.addPost} updateNewPostText={props.updateNewPostText}/> }/> */}
        </div>
      </div>
  );
}


export default App;
