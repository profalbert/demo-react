import React from 'react';

const Technologies = () => {
  return (
   <div>
   </div>
  );
}

export default Technologies;