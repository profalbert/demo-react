import React from 'react';
// import Dialogs from './Dialogs';
// import {updateNewMessageBodyCreator, sendMessageCreator} from '../redux/dialogs-reducer'; 
// import {connect} from 'react-redux';
import Redirect from 'react-router-dom/es/Redirect';
import {connect} from 'react-redux';


let mapStateToPropsForRedirect = (state) => {
  return {
		isAuth: state.auth.isAuth
  }
}

let withAuthRedirect = (Component) => {
  class RedirectComponent extends React.Component {
    render() {
			if (!this.props.isAuth) return <Redirect to={'/login'} />;
      return  (
        <Component {...this.props}/>
			);
    }
	}
  let ConnectedAuthRedirectComponent = connect(mapStateToPropsForRedirect)(RedirectComponent);
  return ConnectedAuthRedirectComponent;
}




// const DialogsContainer = connect(mapStateToProps, mapDispatchToProps)(AuthRedirectComponent);

export default withAuthRedirect;