let initialState = {

}

export const sidebarReducer = (state = initialState, action) => {
	return state;
}