const UPDATE_NEW_MESSAGE_BODY = 'UPDATE_NEW_MESSAGE_BODY';
const SEND_MESSAGE = 'SEND_MESSAGE';

let initialState = {
	messagesData: [
	 {id: 1, message: 'Hi'},
	 {id: 2, message: 'How are you doing?'}, 
	 {id: 3, message: 'GG'}, 
	 {id: 4, message: 'GG'}, 
	 {id: 5, message: 'GG'}, 
	 {id: 6, message: 'GG'}
	],
	dialogsData: [
	 {id: 1, name: 'Dimych'},
	 {id: 2, name: 'Andrey'}, 
	 {id: 3, name: 'Sveta'}, 
	 {id: 4, name: 'Sasha'}, 
	 {id: 5, name: 'Valera'}, 
	 {id: 6, name: 'Albert'}
	],
	newMessageBody: ""
}

export const dialogsReducer = (state = initialState, action) => {
 switch(action.type) {
 	case UPDATE_NEW_MESSAGE_BODY:
 	 return {
 	 	...state,
 	 	newMessageBody: action.body
 	 };
	 case SEND_MESSAGE: 
	  let body = state.newMessageBody;
	  return {
	  	...state,
	  	messagesData: [...state.messagesData, {id: 7, message: body}], // это новый синтаксис пуша эдемента в массив (push)
	  	newMessageBody: ''
	  };
	 default: 
	  return state;
 }
}

export const sendMessageCreator = () => ({
 type: SEND_MESSAGE
});
export const updateNewMessageBodyCreator = (body) => ({ 
	type: UPDATE_NEW_MESSAGE_BODY, body: body 
});