import React from 'react';
import s from './Header.module.css';
import {NavLink} from 'react-router-dom';

const Header = (props) => {
  return (
   <header className={s.header}>
     <img src="https://bcassetcdn.com/asset/logo/4c8f8b36-51b9-4ebf-b20c-00e5c25719c3/logo?v=4&text=Logo+Text+Here" alt=""/>

     <div className={s.loginBlock}>
     	{ props.isAuth ? props.login
     	 : <NavLink to={'/login'}>Login</NavLink>
     	}
     </div>
   </header>
  );
}

export default Header;