import React from 'react';
import Users from './Users';
import Preloader from '../common/preloader/Preloader';
import {connect} from 'react-redux';
import {follow, unfollow,
 setCurrentPage,
 toggleFollowingProgress, 
 getUsers} from '../redux/users-reducer'; 
import withAuthRedirect from '../../hoc/withAuthRedirect';
import {compose} from 'redux';



class UsersAPIComponent extends React.Component {

  // constructor(props) { // бесполезный констректор, ведь и так передаются props
  //  super(props);
  // }
 
 componentDidMount() {
 	this.props.getUsers(this.props.currentPage, this.props.pageSize);  

  /* не нужно условие, ведь оно и так загрузится только один раз
	  if(this.props.users.length === 0) {

	  }
  */
 }
 
 onPageChanged = (pageNumber) => {
 	this.props.getUsers(pageNumber, this.props.pageSize);  
  this.props.setCurrentPage(pageNumber);
 }

	render(){
	 return (
	 	<>
	 	 {this.props.isFetching ? <Preloader />  : null}
				<Users  totalUsersCount={this.props.totalUsersCount}
                pageSize={this.props.pageSize}
                currentPage={this.props.currentPage}
                onPageChanged={this.onPageChanged}
                users={this.props.users}
                follow={this.props.follow}
                unfollow={this.props.unfollow}
                toggleFollowingProgress={this.props.toggleFollowingProgress}
                followingInProgress={this.props.followingInProgress}
				 />
			 </>
		);
	}
}


let mapStateToProps = (state) => {
  return {
    users: state.usersPage.users,
    pageSize: state.usersPage.pageSize,
    totalUsersCount: state.usersPage.totalUsersCount,
    currentPage: state.usersPage.currentPage,
    isFetching: state.usersPage.isFetching,
    followingInProgress: state.usersPage.followingInProgress
  }
}
/*
let mapDispatchToProps = (dispatch) => {
  return {
    follow(userId) {
      dispatch(followAC(userId));
    },
    unfollow(userId) {
      dispatch(unfollowAC(userId));      
    },
    setUsers(users) {
      dispatch(setUsersAC(users));      
    },
    setCurrentPage(pageNumber) {
    	dispatch(setCurrentPageAC(pageNumber));
    },
    setTotalUsersCount(totalCount) {
    	dispatch(setTotalUsersCountAC(totalCount));
    },
    toggleIsFetching(isFetching) {
    	dispatch(toggleIsFetchingAC(isFetching));
    }
  }
}
*/



/*Сократили код с диспачами, если одинаковое название, то можно
сократить до одного слова (flow: flow = flow),

Функция mapDispatchToProps разрастается. 
По факту мы в колбэках что делаем? принимаем параметр, 
делегируем его экшен-криейтору и дальше полученный экшен диспатчим!

Так вот, если оно так, то можно сократить код, 
передавая вторым параметром в функцию 
connect не функцию mapDispatchToProps, а передавая просто объект, 
состоящий из экшенКриейторов! как-то так))*/

let mapDispatchToProps = {
  follow,
  unfollow,
  setCurrentPage,
  toggleFollowingProgress,
  getUsers: getUsers
}

const UsersContainer = compose(
	connect(mapStateToProps, mapDispatchToProps),
  withAuthRedirect
)(UsersAPIComponent)

export default UsersContainer;







