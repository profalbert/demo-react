import React from 'react';
import Profile from './Profile';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import {setUserProfileThunk,
 getStatusThunk, updateStatusThunk} from '../redux/profile-reducer';
import withAuthRedirect from '../../hoc/withAuthRedirect';
import {compose} from 'redux';



class ProfileContainer extends React.Component{

	componentDidMount() {
		let userId = this.props.match.params.userId;
		if(!userId) {
			userId = 2;
		}
		
		this.props.setUserProfileThunk(userId); 
		// setTimeout (()=>{
    //   this.props.getStatusThunk(userId);       
		// }, 1000)
    this.props.getStatusThunk(userId);
	} 

	render() {
		return (
		 <Profile {...this.props}
							profile={this.props.profile} 
							status={this.props.status}
							updateStatus={this.props.updateStatusThunk}/>
		);
	}
}

let mapStateToProps = (state) => {
  return {
		profile: state.profilePage.profile,
		status: state.profilePage.status
  }
}
let mapDispatchToProps = {
	setUserProfileThunk,
	getStatusThunk,
	updateStatusThunk
}


export default compose(
	connect(mapStateToProps, mapDispatchToProps),
	withRouter,
  withAuthRedirect
)(ProfileContainer);


