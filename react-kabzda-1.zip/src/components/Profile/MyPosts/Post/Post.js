import React from 'react';
import s from './Post.module.css';

const Post = (props) => {
  return (
   <div className={s.item}>
    <img src="http://teleprogramma.pro/wp-content/uploads/2016/04/78d7121d83dafb1d7d2ed1719bc119c5.jpg" alt=""/>
     {props.message}
     <div>
       <span>like</span> {props.likesCount}
     </div>
   </div>       
  );
}

export default Post;