import React from 'react';
import s from './ProfileInfo.module.css';
import Preloader from '../../common/preloader/Preloader';
import ProfileStatus from './ProfileStatus';


const ProfileInfo = (props) => {
  if(!props.profile) {
    return (
    <Preloader />
    );
  } 

  return (
   <div>
     <div className={s.descriptionBlock}>
       <img src={props.profile.photos.large  != null ? props.profile.photos.large : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS9k57mYvdSiDsrF0MmUdfdbV6LOjr24T5jV3DomGBl3mh2Akw7DA" } alt="photos-user"/>
       <ProfileStatus status={props.status}
							        updateStatus={props.updateStatus}/>
     </div>      
   </div>
  );
}

export default ProfileInfo;