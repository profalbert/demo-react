import React from 'react';
import s from './Preloader.module.css';


let Preloader = (props) => {
	return (
  <div className={s.loader}>
   <img src='http://i.imgur.com/jtkTPvb.gif' alt="preloader"/>
  </div>
	);
}

export default Preloader;