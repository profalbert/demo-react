import React from 'react';

const Header = () => {
  return (
    <div>
      <a href="#$">Home</a>-
      <a href="#$">News Feed</a>-
      <a href="#$">Messages</a>
    </div>
  );
}

export default Header;